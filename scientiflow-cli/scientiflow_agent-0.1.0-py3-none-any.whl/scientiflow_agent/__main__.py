from scientiflow_agent.main import main


main()