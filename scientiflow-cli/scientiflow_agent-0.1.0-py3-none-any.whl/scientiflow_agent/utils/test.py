import sys
def doSomething(arr1, arr2, arr3):
    #Do Something
    return set(arr1) & set(arr2) & set(arr3)
    
    
arr1 = [int(i) for i in input().split()]
arr2 = [int(i) for i in input().split()]
arr3 = [int(i) for i in input().split()]

outputVal = doSomething(arr1, arr2, arr3)
print (output)
                